export default function useStateWithStorage(
  key: string,
  defaultValue: unknown
) {}
