Create a Mongo database with the name:
league-register

As initial collection you can use:
leagues

Modify ".env" file variable "MONGO_URI" if needed.

Place your football-data.org token in ".env" file 
UR_TOKEN=___YOUR_TOKEN___

Install dependencies:
npm i

Start App:
npm run dev

Open Apollo Server
http://localhost:4000/
